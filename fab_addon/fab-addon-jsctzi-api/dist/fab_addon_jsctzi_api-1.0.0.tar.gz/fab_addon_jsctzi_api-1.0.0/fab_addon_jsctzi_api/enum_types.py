# File auto generated, DO NOT edit because it will be smashed

from enum import Enum


class role_rights_role_enum(Enum):
    ADMIN = "admin"
    DEVELOPER = "developer"