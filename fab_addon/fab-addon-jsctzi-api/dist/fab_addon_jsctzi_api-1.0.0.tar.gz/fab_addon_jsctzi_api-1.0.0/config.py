ADDON_NAME = "fab_addon_jsctzi_api"
FULL_ADDON_NAME = ADDON_NAME
