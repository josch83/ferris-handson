# File auto generated, DO NOT edit because it will be smashed

from enum import Enum


class role_rights_entity_enum(Enum):
    ADDRESS = "address"
    ROLE_RIGHTS = "role_rights"
    USER_ACCOUNT = "user_account"


class role_rights_role_enum(Enum):
    ADMIN = "admin"
    USER = "user"