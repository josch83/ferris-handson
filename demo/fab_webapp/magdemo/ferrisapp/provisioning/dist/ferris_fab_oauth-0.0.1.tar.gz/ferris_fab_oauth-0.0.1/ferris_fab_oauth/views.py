from flask import redirect, request
from flask_appbuilder.security.views import AuthOAuthView
from flask_appbuilder import expose


class AuthOAUTHView(AuthOAuthView):

    def __init__(self):
        super().__init__()

    @expose('/logout/', methods=['GET', 'POST'])
    def logout(self):

        super(AuthOAUTHView, self).logout()
        #redirect_url = self.appbuilder.app.config["WEBAPP_ADDRESS"]
        redirect_url = request.url_root
        print(f"{redirect_url}", flush=True)
        oauth_providers_filtered_list = [provider_config for provider_config in self.appbuilder.sm.oauth_providers if provider_config["name"] == "keycloak"]
        if oauth_providers_filtered_list:
            # pick the first
            provider_info = oauth_providers_filtered_list[0]
        
        api_base_url = provider_info["remote_app"]["api_base_url"]
        logout_uri = api_base_url + "/logout?redirect_uri=" + redirect_url

        return redirect(logout_uri)
