#from flask_appbuilder.security.sqla.manager import SecurityManager
from ferrisapp.app.manager import FerrisSecurityManager
from flask import session


#class KeycloakRoleBasedSecurityManager(SecurityManager):
class KeycloakRoleBasedSecurityManager(FerrisSecurityManager):

    def set_oauth_session(self, provider, oauth_response):
        """
        Set the current session with OAuth user secrets
        """
        # Get this provider key names for token_key and token_secret
        token_key = self.appbuilder.sm.get_oauth_token_key_name(provider)
        token_secret = self.appbuilder.sm.get_oauth_token_secret_name(provider)
        # Save users token on encrypted session cookie
        session["oauth"] = (
            oauth_response[token_key],
            oauth_response.get(token_secret, ""),
            oauth_response["refresh_token"],
        )
        session["oauth_provider"] = provider

    def _get_oauth_user_info(self, provider, response=None):
        if provider in ["keycloak", "keycloak_before_17"]:
            # me = self.appbuilder.sm.oauth_remotes[provider].get(
            #     "openid-connect/userinfo"
            # )
            #tok = session["oauth"][0]
            #header = {"Authorization": f"Bearer {tok}"}
            me = self.appbuilder.sm.oauth_remotes[provider].get(
                "userinfo", #headers=header
            )
            me.raise_for_status()
            data = me.json()            
            
            keycloak_client_id = ""
            for oauth_provider in self.appbuilder.sm.oauth_providers:
                if provider == oauth_provider["name"]:
                    keycloak_client_id = oauth_provider["remote_app"]["client_id"]
                    break
            userinfo_return_dict = {
                "username": data.get("preferred_username", ""),
                "first_name": data.get("given_name", ""),
                "last_name": data.get("family_name", ""),
                "email": data.get("email", ""),
                #"role_keys": data.get("roles", data["resource_access"][keycloak_client_id].get("roles", [])),
                "role_keys": data.get("roles", data["resource_access"][keycloak_client_id].get("roles", [])) if data.get("resource_access") is not None else data.get("roles", []),
            }
            return userinfo_return_dict
        else:
            return {}
    get_oauth_user_info = _get_oauth_user_info
