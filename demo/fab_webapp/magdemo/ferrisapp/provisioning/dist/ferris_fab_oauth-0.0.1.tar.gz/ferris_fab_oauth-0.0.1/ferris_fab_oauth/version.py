VERSION_MAJOR = 0
VERSION_MINOR = 0
VERSION_BUILD = 1
VERSION_INFO = (VERSION_MAJOR, VERSION_MINOR, VERSION_BUILD)
VERSION_STRING = "%d.%d.%d" % VERSION_INFO
AUTHOR_NAME = "Federico Padua"
DESCRIPTION = "Oauth Keycloak connection manager for Flask-AppBuilder>= 4.2.0 ."
AUTHOR_EMAIL = "federico.padua@integrationalpha.com"

__version__ = VERSION_INFO