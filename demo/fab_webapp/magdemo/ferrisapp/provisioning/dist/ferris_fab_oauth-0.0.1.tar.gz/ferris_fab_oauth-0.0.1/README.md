This module is a Keycloak security manager class to handle role based
access when the Identity provider is Keycloak.
This has been tested with the latest Keycloak image (Quark distribution).


## Usage

### Override security_manager of Flask-Appbuilder in one of two ways

#### 1. During FAB application init

```python
from flask_appbuilder import AppBuilder
from ferris_fab_oauth.security import KeycloakRoleBasedSecurityManager

appbuilder = AppBuilder(
    app=app,
    security_manager_class=KeycloakRoleBasedSecurityManager,
)

```

#### 2. Via app configuration (config.py/Consul config):

* If using ```config.py```:


```python 
FAB_SECURITY_MANAGER_CLASS = 'ferris_fab_oauth.security.KeycloakRoleBasedSecurityManager'
```

* If using Consul config:

```json 
"FAB_SECURITY_MANAGER_CLASS": "ferris_fab_oauth.security.KeycloakRoleBasedSecurityManager"
```

Additional to this change of configuration about the security manager class used, there are additional configurations to be added.
A working and more complete section of the configuration needed to use this security manager, in the case of Consul is (similar to be added for ```config.py```):

```json
{
    "AUTH_USER_REGISTRATION": true,
    "AUTH_USER_REGISTRATION_ROLE": "default_role",
  	"AUTH_ROLES_SYNC_AT_LOGIN": true,
    "AUTH_TYPE": 4,
    "OAUTH_PROVIDERS": [

        {
            "name": "keycloak",
            "icon": "fa-key",
            "token_key": "access_token",
            "remote_app": {
                "client_id": "keycloak_client_id",
                "client_secret": "client_secret",
                "api_base_url": "http://<network_docker_host>:<network_docker_port>/realms/<keycloak_client>/protocol/openid-connect/",
                "client_kwargs": {
                    "scope": "email profile openid roles"
                },
              	"jwks_uri":"http://<network_docker_host>:<network_docker_port>/realms/<keycloak_client>/protocol/openid-connect/certs",
                "access_token_url": "http://<network_docker_host>:<network_docker_port>/realms/<keycloak_client>/protocol/openid-connect/token",
                "authorize_url": "http://<host_reachable_outside_docker>:<port_reachable_outside_docker>/realms/<keycloak_client>/protocol/openid-connect/auth",
                "request_token_url": null
            }
        }

    ],
    "FAB_SECURITY_MANAGER_CLASS": "ferris_fab_oauth.security.KeycloakRoleBasedSecurityManager",
    "AUTH_ROLES_MAPPING": {
        "idp_role_one": [
            "webapp_role_one_mapping"
        ]
    }  
}
```

A concrete example of the previous configuration would be the following:

```json
{
    "AUTH_USER_REGISTRATION": true,
    "AUTH_USER_REGISTRATION_ROLE": "analyst",
  	"AUTH_ROLES_SYNC_AT_LOGIN": true,
    "AUTH_TYPE": 4,
    "OAUTH_PROVIDERS": [

        {
            "name": "keycloak",
            "icon": "fa-key",
            "token_key": "access_token",
            "remote_app": {
                "client_id": "swisscard-webapp",
                "client_secret": "xkYtIzI6FIQY4czaJFUK6Eahvx3cAYK0",
                "api_base_url": "http://ferris-keycloak:8080/realms/swisscard/protocol/openid-connect/",
                "client_kwargs": {
                    "scope": "email profile openid roles"
                },
              	"jwks_uri":"http://ferris-keycloak:8080/realms/swisscard/protocol/openid-connect/certs",
                "access_token_url": "http://ferris-keycloak:8080/realms/swisscard/protocol/openid-connect/token",
                "authorize_url": "http://localhost:9900/realms/swisscard/protocol/openid-connect/auth",
                "request_token_url": null
            }
        }

    ],
    "FAB_SECURITY_MANAGER_CLASS": "ferris_fab_oauth.security.KeycloakRoleBasedSecurityManager",
    "AUTH_ROLES_MAPPING": {
        "admin": [
            "admin"
        ],
        "agent": [
            "agent"
        ],
        "analyst": [
            "analyst"
        ],
        "compliance": [
            "compliance"
        ]
    }  
}
```




### Setting Identity Provider

Below are step-by-step instructions for basic Keycloak setup that is needed in order for [ferris-fab-oauth] to work properly. 


#### 1. Create REALM

- Create realm that will be used

#### 2. Create Client

- Create client with following settings (replace FAB_DOMAIN with domain (and port) of your FAB application):

| Field                    | Value                              |
|--------------------------|------------------------------------|
|Client Protocol           | openid-connect                     |
|AccessType                | confidential                       |
|Home URL                  | http://<FAB_DOMAIN>/               |
|Valid redirect URIs       | http://<FAB_DOMAIN>/oauth-authorized/*  |
|                          | http://<FAB_DOMAIN>/login          |
|Valid post logout redirect URIs       | http://<FAB_DOMAIN>  |
|                          | http://<FAB_DOMAIN>/login          |



#### 3. Create client roles that will match those used by FAB application (Admin and Public by default) (OPTIONAL, one can define the roles mapping with a some work)

- Your Client &#8594; Roles &#8594; Add Role 
 
#### Pass roles along with other data in ID Token (adapt as small difference in UI for latest Keycloak)

- Your Client &#8594; Mappers &#8594; Add Builtin &#8594; client roles &#8594; check Add checkbox &#8594; Add Selected

Then edit created Mapper by changing following:

| Field                    | Value                              |
|--------------------------|------------------------------------|
|Token Claim Name          | roles   (optional, this module works even if not defined, by accessing client specific roles...)                           |
|Add to ID token           | ON                                 |


### Create user for your Client and assign desired role of your client to it


