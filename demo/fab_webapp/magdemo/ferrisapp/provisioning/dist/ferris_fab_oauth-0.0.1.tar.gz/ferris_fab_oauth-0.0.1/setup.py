import importlib
import os

from setuptools import find_packages, setup


config = importlib.import_module("config")
version = importlib.import_module(f"{config.FULL_ADDON_NAME}.version")


def fpath(name):
    return os.path.join(os.path.dirname(__file__), name)


def read(fname):
    return open(fpath(fname)).read()


def desc():
    return read('README.md')


setup(
    name=config.FULL_ADDON_NAME,
    version=version.VERSION_STRING,
    url='https://github.com/Integration-Alpha/ferris-fab-modules-ia-fork/tree/ia-main/ferris-fab-oauth',
    license='BSD',
    author=version.AUTHOR_NAME,
    author_email=version.AUTHOR_EMAIL,
    description=version.DESCRIPTION,
    long_description_content_type='text/markdown',
    long_description=desc(),
    packages=find_packages(),
    package_data={'': ['LICENSE']},
    include_package_data=True,
    zip_safe=False,
    platforms='any',
    install_requires=[
        'Flask-AppBuilder>=4.2.0',
        'Authlib',
    ],
    tests_require=[
        'nose>=1.0',
    ],
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Environment :: Web Environment',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Topic :: Software Development :: Libraries :: Python Modules'
    ],
    test_suite='nose.collector'
)
