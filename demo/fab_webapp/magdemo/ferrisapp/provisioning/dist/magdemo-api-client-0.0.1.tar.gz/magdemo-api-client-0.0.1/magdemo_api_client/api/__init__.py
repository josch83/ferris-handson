from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from magdemo_api_client.api.address_api import AddressApi
from magdemo_api_client.api.role_rights_api import RoleRightsApi
from magdemo_api_client.api.user_account_api import UserAccountApi
